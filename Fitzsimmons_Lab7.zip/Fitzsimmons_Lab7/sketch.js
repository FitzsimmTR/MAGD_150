yBird = 200;
xBird = 10;
hitPumpkin = 0;
hitBlock = false;
var x = [];
var y = [];
var s = []; //scale for pumpkin
var r = []; //rotate fpr [pumpkin]
//staticBlockArray
var xBlock = [50, 250, 300, 350, 530];
var yBlock = [50, 350, 250, 200, 330];

function setup() {
  createCanvas(600, 400);

  angleMode(DEGREES);
  for (let i = 0; i < 7; i++) {
    x[i] = random(600, 1000);
    y[i] = random(15, 385);
    s[i] = random(1.0, 2.0);
    r[i] = random(0, 360);
  }
  print("numPumpkins", x.length);
  print("numBlocks", xBlock.length);
}

function draw() {
  background(220);

  if (yBird < 0) {
    yBird = 0;
  }
  if (yBird > 380) {
    yBird = 380;
  }
  if (xBird < 0) {
    xBird = 0;
  }
  moveBlocks();
  //draw blocks.
  for (let i = 0; i < 5; i++) {
    rect(xBlock[i], yBlock[i], 50, 30);
  }
  //run pumpkin array. (draws and moves pumpkins)
  movePumpkins();

  //bird
  ellipse(xBird, yBird, 20, 15);
}

function keyPressed() {
  if (keyCode === UP_ARROW) {
    yBird -= 20;
  } else if (keyCode === DOWN_ARROW) {
    yBird += 20;
  } else if (keyCode === RIGHT_ARROW) {
    xBird += 30;
  } else if (keyCode === LEFT_ARROW) {
    xBird -= 30;
  }

  print("Pumpkin Counter: ", checkHitPumpkin()); //Lab 7 print/return requirement (return value is located in checkHitPumpkin).

  checkHitBlock();
}

function movePumpkins() {
  //pumpkins
  push();
  for (let i = 0; i < 7; i++) {
    drawPumpkin(x[i]--, y[i], s[i], r[i]--); //Lab 7 draw multiple copies requirement

    //checks circle is off screen. Restarts circle position at right side of screen and at random y.
    if (x[i] < -15) {
      x[i] = 600;
      y[i] = random(15, 385);
    }
  }
  pop();
  checkHitPumpkin();
}

//Lab 7 function requirement (includes passing unique x & y, scale, rotate, translate, push/pop, and anglemode).
function drawPumpkin(xx, yy, ss, rr) {
  let x = 0;
  let y = 0;
  push();
  translate(xx, yy);
  scale(ss);
  rotate(rr);
  //drawing pumpkin face
  fill("green");
  triangle(0, -20, 3, -18, 0, -10);
  fill("orange");
  circle(x, y, 30); //drawing and moving my pumpkin
  fill(0);
  triangle(x - 5, y - 7, x - 3, y - 3, x - 7, y - 3);
  triangle(x + 5, y - 7, x + 3, y - 3, x + 7, y - 3);
  triangle(0, 0, 1, 2, -1, 2);
  angleMode(DEGREES);
  arc(0, 5, 13, 7, 0, 180);
  noStroke();
  fill("orange");
  rect(-4, 4, 2.5, 2.5);
  rect(2, 4, 2.5, 2.5);
  rect(-1, 7, 2.5, 2.5);
  pop();
}

function checkHitPumpkin() {
  for (let i = 0; i < 7; i++) {
    let d = dist(xBird, yBird, x[i], y[i]);
    if (d < 15) {
      hitPumpkin++;
      x[i] = -50;
    }
  }
  return hitPumpkin; //Lab 7 print/return requirement
}

function checkHitBlock() {
  hitBlock = false;

  for (let i = 0; i < 5; i++) {
    if (
      xBird > xBlock[i] &&
      yBird > yBlock[i] &&
      xBird < xBlock[i] + 50 &&
      yBird < yBlock[i] + 30
    ) {
      hitBlock = true;
      hitPumpkin = 0;
    }
  }
}

function moveBlocks() {
  for (let i = 0; i < 5; i++) {
    if (mouseX > xBlock[i] && mouseX < xBlock[i] + 50) {
      yBlock[i] = mouseY;
    }
  }
}
