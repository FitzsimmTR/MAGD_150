//must complete initial click on canvas to focus scope
xCube = 190;
iClick = false; //initial click
yBall = 15; //y position of the ball assigned as starting position
goingDown = true;
playClicked = false;
leaveClicked = false;
offClicked = false;
playX1 = 50;
playY1 = 180;
playX2 = 170;
playY2 = 260;
leaveX1 = 230;
leaveY1 = 180;
leaveX2 = 350;
leaveY2 = 260;
offX1 = 180;
offY1 = 300;
offX2 = 220;
offY2 = 340;

function setup() {
  createCanvas(450, 600);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() {
  if (offClicked === true) {
    offScrn();
  } else if (playClicked === true) {
    pong();
  } else if (leaveClicked === true) {
    leaveScrn();
  }
  //else if ((offClicked === false) && (mouseY > offY1) && (mouseX > offX1) && (mouseY < offY2) && (mouseX < offX2) && (keyIsPressed)) {
  //if (keyCode === ENTER) {
  //offClicked = true
  //}
  //}
  else {
    background(255);

    //computerEdge
    stroke(0);
    strokeWeight(5);
    fill(40);
    rect(0, 0, 400, 400);

    //computerScreen
    fill(230);
    rect(20, 20, 360, 360);

    //computerStatusLight
    fill(255);
    strokeWeight(2);
    stroke(191, 255, 0, 1);
    rect(385, 385, 6, 6);

    //dell
    fill(200);
    stroke(100);
    textSize(15);
    text("WOPR", 200, 395);

    frameRate(3);
    textSize(32);
    fill(255);
    stroke(random(0, 255), random(0, 255), random(0, 255), 1);
    strokeWeight(4);
    textAlign(CENTER);
    text("Do You Want", 200, 80);
    text("To Play A Game?", 200, 130);

    //playButton
    fill(26, 176, 0, 1);
    stroke(16, 106, 0, 1);
    strokeWeight(5);
    rect(50, 180, 120, 80);

    fill(255);
    text("PLAY", 110, 230);

    //leaveButton
    ellipseMode(CORNER);
    fill(219, 7, 0, 1);
    stroke(133, 4, 0, 1);
    ellipse(230, 180, 120, 80);

    fill(255);
    text("LEAVE", 290, 230);

    //powerOffButton
    fill(40, 46, 161, 1);
    stroke(26, 29, 102, 1);
    ellipse(180, 300, 40);

    fill(255);
    textSize(16);
    text("OFF", 200, 325);
  }
}

function mouseClicked() {
  playClicked = false;
  if (
    mouseY > playY1 &&
    mouseX > playX1 &&
    mouseY < playY2 &&
    mouseX < playX2
  ) {
    playClicked = true;
  }

  leaveClicked = false;
  if (
    mouseY > leaveY1 &&
    mouseX > leaveX1 &&
    mouseY < leaveY2 &&
    mouseX < leaveX2
  ) {
    leaveClicked = true;
  }

  iClick = true;

  print("click", leaveClicked, mouseX, leaveX1);
}

function keyPressed() {
  if (keyCode === ENTER) {
    offClicked = true;
  }
  if (
    mouseY > offY1 &&
    mouseX > offX1 &&
    mouseY < offY2 &&
    mouseX < offX2 &&
    keyIsPressed
  ) {
    offClicked = true;
  }
  print("offClicked");
}

function pong() {
  print("pong");
  push();
  // createCanvas(450, 600);
  frameRate(20);

  background(220);
  stroke(0);
  strokeWeight(3);

  if (keyIsPressed) {
    if (key == "a") {
      xCube = xCube - 20;
    } else {
      if (key == "d") {
        xCube = xCube + 20;
      }
    }
  }

  if (xCube < 0) {
    xCube = 0;
  }
  if (xCube > 380) {
    xCube = 380;
  }

  if (xCube > 155) {
    if (xCube < 255) {
      hitCube = true;
    } else {
      hitCube = false;
    }
  } else {
    hitCube = false;
  }

  rect(xCube, 500, 70, 30);

  if (iClick === true) {
    if (goingDown === true) {
      //animate ball going down
      if (hitCube === true) {
        bounceLevel = 500;
      } else {
        bounceLevel = 600;
      }
      if (yBall < bounceLevel) {
        for (i = 0; i < 5; i++) {
          ellipse(225, yBall, 30, 30);
          yBall = yBall + 10;
        }
      } else {
        goingDown = false;
      }
    } else {
      //animate ball going up
      if (yBall > 0) {
        for (i = 0; i < 5; i++) {
          ellipse(225, yBall, 30, 30);
          yBall = yBall - 10;
        }
      } else {
        goingDown = true;
      }
    }
  }
  pop();
}

function leaveScrn() {
  stroke(0);
  fill(230);
  rect(20, 20, 360, 360);

  fill(26, 176, 0, 1);
  stroke(191, 255, 0, 1);
  strokeWeight(2);
  textAlign(LEFT);
  textSize(25);
  text("Greetings Professor Falken", 30, 70);
  textSize(15);
  text("How about a nice game of chess?", 30, 90);
}

function offScrn() {
  fill(30);
  stroke(0);
  rect(20, 20, 360, 360);
  print("offScrn");

  fill(255);
  strokeWeight(2);
  stroke(219, 7, 0, 1);
  rect(385, 385, 6, 6);
}