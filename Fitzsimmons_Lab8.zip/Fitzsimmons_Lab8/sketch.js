let img;
let img2; 
let img3;
let img4;

function preload()
{
  img = loadImage('assets/Lab8_img1.jpg');
  img2 = loadImage('assets/Lab8_img2.png');//transparent background
  img3 = loadImage('assets/Lab8_img3.png');//transparent background
  img4 = loadImage('assets/Lab8_img4.png');//transparent background
}


function setup() {
  colorMode(RGB, 255, 255, 255)
  createCanvas(600, 400);
  image(img, 0, 0,  600, 400);
  image(img2, 0, 0, 600, 400);
  image(img3, 200, 100, 200, 200); //base moon
  imageMode(CENTER);
  image(img4, 200, 100, 200, 200); //moveable moon
}

function draw() {

  let moonSize = 1;

  if ( (mouseY >= 0) 
      && (mouseY <= 200) ) {
    moonSize = mouseY 
  }
  else if ( (mouseY > 200)
           && (mouseY < 400) ) 
  {
    moonSize = 200 - (mouseY - 200)
  }
  imageMode(CENTER);
  image(img, 300, 200, mouseX + 600, mouseX + 400);
  imageMode(CORNER);
  image(img2, 0, 0, 600, 400);
  image(img3, 200, 100, 200, 200);
  imageMode(CENTER);
  image(img4, mouseX, mouseX - 100, moonSize, moonSize);
  
  textAlign(CENTER);
  rectMode(CENTER);
  textSize(40);
  textFont('Helvetica');
  stroke(0);
  strokeWeight(7);
  fill(52, 82, 235);
  text('SPACE - THE FINAL FRONTIER', 300, 375, 600, 60);
}
